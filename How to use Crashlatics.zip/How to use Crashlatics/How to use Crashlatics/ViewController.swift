//
//  ViewController.swift
//  How to use Crashlatics
//
//  Created by Abhishek Verma on 25/03/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit
import Crashlytics

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func Crash(_ sender: Any) {
        Crashlytics.sharedInstance().crash()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

